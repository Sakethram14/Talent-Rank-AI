import { createFileRoute } from "@tanstack/react-router";
import { Card, Chip, SectionTitle } from "@/components/ui-primitives";

export const Route = createFileRoute("/_authenticated/export")({
  head: () => ({ meta: [{ title: "Export Center — TalentRank AI" }, { name: "description", content: "Validate the shortlist and export final candidate selections to CSV." }] }),
  component: ExportPage,
});

function ExportPage() {
  return (
    <div className="max-w-[1100px] mx-auto p-8 space-y-6">
      <div>
        <h1 className="font-display text-3xl font-medium text-zinc-100">Export Center</h1>
        <p className="text-zinc-400 mt-1 text-sm">Validate the shortlist and submit the final hackathon CSV.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-5"><SectionTitle>Shortlist</SectionTitle><div className="font-display text-3xl text-zinc-100">50</div><div className="text-xs text-zinc-500">candidates ready</div></Card>
        <Card className="p-5"><SectionTitle>Validation</SectionTitle><div className="font-display text-3xl text-emerald-400">100%</div><div className="text-xs text-zinc-500">schema checks passed</div></Card>
        <Card className="p-5"><SectionTitle>Format</SectionTitle><div className="font-display text-3xl text-zinc-100">CSV</div><div className="text-xs text-zinc-500">UTF-8 · headers included</div></Card>
      </div>

      <Card className="p-6">
        <SectionTitle>Submission Preview</SectionTitle>
        <pre className="mt-3 text-[11px] text-zinc-300 font-mono bg-base/60 p-4 rounded-lg ring-1 ring-white/5 overflow-x-auto">
{`candidate_id,name,overall_score,confidence,recommendation
c_1,Aarav Patel,94,0.96,fast_track
c_2,Elena Vakhromeeva,93,0.95,fast_track
c_3,Marcus Chen,91,0.93,strong_match
…`}
        </pre>
        <div className="mt-5 flex items-center justify-between">
          <Chip tone="good">Ready to submit</Chip>
          <button className="px-4 py-2 bg-accent text-white text-sm font-medium rounded-lg hover:bg-accent/90 shadow-lg shadow-accent/20">Download CSV</button>
        </div>
      </Card>
    </div>
  );
}
