import { createFileRoute } from "@tanstack/react-router";
import { useAuth } from "@/hooks/use-auth";
import { Card, SectionTitle, Chip } from "@/components/ui-primitives";

export const Route = createFileRoute("/_authenticated/workspace")({
  head: () => ({ meta: [{ title: "Workspace — TalentRank AI" }] }),
  component: WorkspacePage,
});

function Section({ title, hint, children }: { title: string; hint?: string; children: React.ReactNode }) {
  return (
    <Card className="p-6">
      <SectionTitle sub={hint}>{title}</SectionTitle>
      {children}
    </Card>
  );
}

function Empty({ label }: { label: string }) {
  return (
    <div className="text-center py-10 text-sm text-zinc-500 border border-dashed border-white/10 rounded-xl">
      {label}
    </div>
  );
}

function WorkspacePage() {
  const { user, signOut } = useAuth();

  return (
    <div className="max-w-[1100px] mx-auto p-8 space-y-6">
      <div className="flex items-end justify-between gap-6 flex-wrap">
        <div>
          <h1 className="font-display text-3xl font-medium text-zinc-100">Your workspace</h1>
          <p className="text-zinc-400 mt-1 text-sm">Profile, saved candidates, search history, and account settings.</p>
        </div>
        <button
          onClick={signOut}
          className="text-sm px-4 py-2 rounded-lg ring-1 ring-white/10 bg-white/[0.03] text-zinc-200 hover:bg-white/[0.06] transition-colors"
        >
          Sign out
        </button>
      </div>

      {/* Profile */}
      <Card className="p-6">
        <div className="flex items-center gap-5">
          {user?.photoURL ? (
            <img src={user.photoURL} alt="" className="size-16 rounded-full ring-1 ring-white/10" />
          ) : (
            <div className="size-16 rounded-full bg-gradient-to-br from-indigo-500 to-fuchsia-500 grid place-items-center text-white text-xl font-semibold">
              {user?.displayName?.[0] ?? "?"}
            </div>
          )}
          <div className="flex-1 min-w-0">
            <div className="text-xl font-medium text-zinc-100 truncate">{user?.displayName}</div>
            <div className="text-sm text-zinc-500 truncate">{user?.email}</div>
            <div className="mt-2 flex gap-2">
              <Chip tone="accent">Recruiter</Chip>
              <Chip>Google · verified</Chip>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Section title="Saved Searches" hint="0 saved"><Empty label="Save a job analysis to revisit it later." /></Section>
        <Section title="Saved Candidates" hint="0 saved"><Empty label="Star candidates from any ranking to bookmark them." /></Section>
        <Section title="Recent Searches" hint="last 30 days"><Empty label="No recent searches yet. Run a job analysis to start." /></Section>
        <Section title="Export History"><Empty label="Exports you create will appear here." /></Section>
        <Section title="Notifications"><Empty label="You're all caught up." /></Section>
        <Section title="Account Settings">
          <div className="text-sm text-zinc-400 space-y-3">
            <div className="flex justify-between"><span>Display name</span><span className="text-zinc-200">{user?.displayName}</span></div>
            <div className="flex justify-between"><span>Email</span><span className="text-zinc-200">{user?.email}</span></div>
            <div className="flex justify-between"><span>Sign-in method</span><span className="text-zinc-200">Google</span></div>
          </div>
        </Section>
      </div>
    </div>
  );
}
