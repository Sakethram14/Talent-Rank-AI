import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Card, SectionTitle } from "@/components/ui-primitives";

export const Route = createFileRoute("/_authenticated/config")({
  head: () => ({ meta: [{ title: "Config Sandbox — TalentRank AI" }, { name: "description", content: "Tune dimension weights and watch rankings recalibrate in real time." }] }),
  component: ConfigPage,
});

type W = "semantic" | "behavior" | "career" | "skill" | "risk" | "availability";
const DEFAULT: Record<W, number> = { semantic: 30, skill: 25, career: 20, behavior: 15, availability: 5, risk: 5 };

function ConfigPage() {
  const [w, setW] = useState(DEFAULT);
  const total = Object.values(w).reduce((a, b) => a + b, 0);
  return (
    <div className="max-w-[1100px] mx-auto p-8 space-y-6">
      <div>
        <h1 className="font-display text-3xl font-medium text-zinc-100">Configuration Sandbox</h1>
        <p className="text-zinc-400 mt-1 text-sm">Adjust how the ranker weights each dimension. Changes are submitted to <span className="font-mono text-zinc-200">POST /config/weights</span> when applied.</p>
      </div>

      <Card className="p-6">
        <SectionTitle sub={`total ${total}%`}>Dimension Weights</SectionTitle>
        <div className="space-y-5 mt-4">
          {(Object.keys(w) as W[]).map((k) => (
            <div key={k}>
              <div className="flex justify-between text-xs mb-2">
                <span className="text-zinc-300 capitalize">{k}</span>
                <span className="text-zinc-100 font-mono">{w[k]}%</span>
              </div>
              <input
                type="range" min={0} max={60} value={w[k]}
                onChange={(e) => setW({ ...w, [k]: Number(e.target.value) })}
                className="w-full accent-indigo-500"
                aria-label={`${k} weight`}
              />
            </div>
          ))}
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <button onClick={() => setW(DEFAULT)} className="px-3 py-1.5 rounded-md text-xs bg-white/[0.04] text-zinc-300 hover:bg-white/[0.08]">Reset</button>
          <button className="px-4 py-1.5 rounded-md text-xs bg-accent text-white font-medium hover:bg-accent/90">Apply weights</button>
        </div>
      </Card>
    </div>
  );
}
