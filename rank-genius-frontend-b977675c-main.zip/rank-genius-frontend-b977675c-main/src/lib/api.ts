/**
 * TalentRank AI API client.
 * Talks to FastAPI backend at VITE_API_BASE_URL (default http://localhost:8000).
 * Falls back to local mock data when the backend is unreachable so the
 * frontend remains demoable without the backend running.
 */
import type { ApiResponse, Candidate, DashboardStats, RankRequest, RankResponse } from "./types";
import { generateCandidate, mockDashboard, mockRank } from "./mock";

const BASE = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.replace(/\/$/, "") ?? "http://localhost:8000";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    ...init,
  });
  if (!res.ok) throw new Error(`API ${res.status}: ${res.statusText}`);
  const json = (await res.json()) as ApiResponse<T> | T;
  if (json && typeof json === "object" && "data" in (json as ApiResponse<T>)) {
    return (json as ApiResponse<T>).data;
  }
  return json as T;
}

async function withFallback<T>(real: () => Promise<T>, mock: () => T): Promise<T> {
  try {
    return await real();
  } catch {
    return mock();
  }
}

export const api = {
  async dashboard(): Promise<DashboardStats> {
    return withFallback(() => request<DashboardStats>("/analytics/dashboard"), mockDashboard);
  },
  async rank(req: RankRequest): Promise<RankResponse> {
    return withFallback(
      () => request<RankResponse>("/candidates/rank", { method: "POST", body: JSON.stringify(req) }),
      () => mockRank(req.job_description, req.top_k ?? 50),
    );
  },
  async candidate(id: string): Promise<Candidate> {
    return withFallback(() => request<Candidate>(`/candidate/${id}`), () => generateCandidate(id));
  },
  async compare(ids: string[]): Promise<Candidate[]> {
    return withFallback(
      () => request<Candidate[]>("/candidate/compare", { method: "POST", body: JSON.stringify({ ids }) }),
      () => ids.map((id) => generateCandidate(id)),
    );
  },
};
