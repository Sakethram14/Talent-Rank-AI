import type { Candidate, DashboardStats, RankResponse } from "./types";

const FIRST = ["Aarav","Priya","Marcus","Elena","Sara","Diego","Wen","Amelia","Rohan","Lina","Ivan","Noor","Kenji","Maya","Tomás","Anika","Felix","Zara","Owen","Mei","Ravi","Camila","Jonas","Sofía","Hugo","Yara","Lucas","Iris","Otto","Nia"];
const LAST = ["Patel","Chen","Vakhromeeva","Mendes","Tanaka","Okafor","Reyes","Singh","Petrov","Ng","Garcia","Hassan","Andersen","Devi","Khan","Silva","Park","Rao","Müller","Costa","Ibrahim","Kovac","Lindberg","Romero"];
const COMPANIES = ["Stripe","Cloudflare","Netflix","Airtable","Vercel","Linear","Anthropic","Datadog","Snowflake","Equinor","Shopify","Razorpay","Swiggy","Notion","Figma","Databricks","HuggingFace","OpenAI"];
const SKILLS = ["Python","Rust","Go","TypeScript","Kubernetes","React","Distributed Systems","PostgreSQL","FAISS","PyTorch","TensorFlow","LLMs","RAG","gRPC","WebAssembly","GraphQL","Redis","Kafka","Airflow","Terraform","System Design","Embeddings"];
const LOCATIONS = ["Bengaluru, IN","Mumbai, IN","San Francisco, US","Berlin, DE","London, UK","Oslo, NO","Singapore","Toronto, CA","Remote"];
const RECS: Candidate["recommendation"][] = ["fast_track","strong_match","consider","review","reject"];
const AVAIL: Candidate["availability"][] = ["open_to_work","passive","not_looking"];

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return (h >>> 0);
}
function rand(seed: number) { let x = seed || 1; return () => { x = (x * 1664525 + 1013904223) >>> 0; return x / 0xffffffff; }; }
function pick<T>(arr: T[], r: () => number): T { return arr[Math.floor(r() * arr.length)]; }
function sample<T>(arr: T[], n: number, r: () => number): T[] {
  const copy = [...arr];
  const out: T[] = [];
  for (let i = 0; i < n && copy.length; i++) out.push(copy.splice(Math.floor(r() * copy.length), 1)[0]);
  return out;
}

export function generateCandidate(id: string, jdSkills: string[] = []): Candidate {
  const r = rand(hash(id));
  const first = pick(FIRST, r), last = pick(LAST, r);
  const name = `${first} ${last}`;
  const company = pick(COMPANIES, r);
  const role = pick(["Staff Engineer","Senior ML Engineer","Principal Architect","Lead Data Scientist","Staff SRE","Senior Backend Engineer"], r);
  const years = Math.floor(r() * 12) + 3;

  const baseSkills = sample(SKILLS, 8 + Math.floor(r() * 6), r);
  const matched = jdSkills.length
    ? jdSkills.filter((s) => baseSkills.includes(s)).concat(baseSkills.filter(s => jdSkills.includes(s))).filter((v,i,a)=>a.indexOf(v)===i)
    : baseSkills.slice(0, 5);
  const missing = jdSkills.filter((s) => !baseSkills.includes(s)).slice(0, 4);

  const semantic = 60 + r() * 38;
  const behavior = 55 + r() * 40;
  const career = 50 + r() * 45;
  const skill = jdSkills.length ? (matched.length / Math.max(jdSkills.length, 1)) * 100 : 60 + r() * 35;
  const risk = r() * 60;
  const availability = 50 + r() * 50;
  const overall = Math.round((semantic * 0.3 + behavior * 0.15 + career * 0.2 + skill * 0.25 + (100 - risk) * 0.05 + availability * 0.05));

  const honeypot = r() < 0.05;
  const rec: Candidate["recommendation"] = honeypot ? "reject" : overall > 85 ? "fast_track" : overall > 75 ? "strong_match" : overall > 65 ? "consider" : "review";

  return {
    id,
    name,
    headline: `${role} @ ${company}`,
    location: pick(LOCATIONS, r),
    years_experience: years,
    current_company: company,
    current_role: role,
    avatar_seed: id,
    overall_score: Math.min(99, overall),
    confidence: 0.7 + r() * 0.29,
    risk_score: Math.round(risk),
    scores: {
      semantic: Math.round(semantic),
      behavior: Math.round(behavior),
      career: Math.round(career),
      skill: Math.round(skill),
      risk: Math.round(risk),
      availability: Math.round(availability),
    },
    matched_skills: matched.slice(0, 8),
    missing_skills: missing,
    all_skills: baseSkills,
    strengths: [
      `${years}+ years shipping production ${pick(["ML systems","distributed infra","data platforms"], r)}`,
      `Led teams at ${company} on ${pick(["scalability","reliability","latency"], r)} initiatives`,
      `Strong open-source signals in ${pick(baseSkills, r)}`,
    ],
    weaknesses: missing.length ? [`Gaps in ${missing.slice(0,2).join(", ")}`, "Limited public writing on system design"] : ["Narrow industry exposure"],
    risk_flags: honeypot
      ? ["Inflated experience claims", "Contradictory dates in employment history"]
      : risk > 40 ? ["Frequent role changes (< 18 mo tenure)"] : [],
    availability: pick(AVAIL, r),
    notice_period_days: [0, 15, 30, 60, 90][Math.floor(r() * 5)],
    recommendation: rec,
    recommendation_text: honeypot
      ? "Rejected: signals indicate profile fabrication. Do not advance."
      : `${rec === "fast_track" ? "Fast-track to final loop" : rec === "strong_match" ? "Strong match" : "Worth a screening call"} based on semantic and career signals.`,
    honeypot,
    honeypot_reasons: honeypot ? ["Skills list exceeds plausible career length", "Tenure overlap conflicts"] : undefined,
    hidden_gem_score: overall > 78 && r() < 0.35 ? Math.round(70 + r() * 25) : undefined,
    career: [
      { company, role, start: `${2026 - Math.min(years, 4)}`, end: null, highlights: [`Led ${pick(["platform","infra","ML"], r)} re-architecture`] },
      { company: pick(COMPANIES, r), role: "Senior Engineer", start: `${2026 - years}`, end: `${2026 - Math.min(years, 4)}` },
    ],
    education: [{ school: pick(["IIT Bombay","Stanford","MIT","IISc","NIT Trichy","ETH Zürich"], r), degree: pick(["B.Tech CS","M.S. CS","Ph.D. ML"], r), year: 2026 - years - Math.floor(r()*3) }],
    evidence: [
      { id: "e1", type: "skill_match", title: `Strong semantic match on ${matched[0] ?? "core stack"}`, detail: `Candidate's resume embeddings rank in the top ${Math.floor(r()*5)+1}% against the JD's required competencies.`, weight: 0.92 },
      { id: "e2", type: "career_signal", title: "Velocity above peer cohort", detail: `Promoted to ${role} ${Math.floor(r()*2)+2} years faster than the median trajectory for this archetype.`, weight: 0.78 },
      { id: "e3", type: "behavioral", title: "High likelihood to respond", detail: `Recent activity signals + notice period of ${[0,15,30,60][Math.floor(r()*4)]} days.`, weight: 0.65 },
      ...(risk > 30 ? [{ id: "e4", type: "risk" as const, title: "Tenure volatility", detail: "Two consecutive sub-18-month stints detected.", weight: 0.55 }] : []),
    ],
  };
}

export function generateCandidates(n: number, jdSkills: string[] = []): Candidate[] {
  return Array.from({ length: n }, (_, i) => generateCandidate(`c_${i + 1}`, jdSkills)).sort((a, b) => b.overall_score - a.overall_score);
}

export function mockRank(jd: string, topK = 50): RankResponse {
  // Naive skill extraction from JD
  const jdLower = jd.toLowerCase();
  const skills = SKILLS.filter(s => jdLower.includes(s.toLowerCase()));
  const candidates = generateCandidates(topK, skills);
  return {
    candidates,
    total_pool: 100_000,
    extracted: {
      skills: skills.length ? skills : ["Python", "Distributed Systems", "Kubernetes"],
      min_years: 5,
      education: ["B.S. or higher in CS / equivalent"],
      behavioral: ["Ownership", "Bias for action", "Cross-functional collaboration"],
    },
  };
}

export function mockDashboard(): DashboardStats {
  return {
    total_candidates: 100_000,
    ai_candidates: 24_318,
    open_to_work: 31_504,
    avg_experience: 6.4,
    honeypots_detected: 1_842,
    recent_rankings: [
      { id: "r1", jd_title: "Staff ML Engineer — RAG Systems", candidates: 50, ts: "2 min ago" },
      { id: "r2", jd_title: "Senior Backend — Distributed Systems", candidates: 100, ts: "1 h ago" },
      { id: "r3", jd_title: "Principal Architect — Edge Compute", candidates: 25, ts: "3 h ago" },
      { id: "r4", jd_title: "Data Platform Lead", candidates: 75, ts: "yesterday" },
    ],
    performance: { latency_ms: 287, throughput_qps: 142 },
  };
}
